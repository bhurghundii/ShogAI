cat black_training_2.csv <(tail +2 white_training_2.csv)  > black_training_3.csv

cat black_training_tmp.csv <(tail +2 white_training_tmp.csv)  > white_training_3.csv